# Campeonato Legacy - Site v3

Inclui:
- Layout atualizado
- Novo índice: Tabela
- Fase de grupos com estatísticas
- Navegação entre Grupos → Semi → Final
- Armazenamento de jogadores

Pronto para uso e hospedagem no GitHub Pages.
