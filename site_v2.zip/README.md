# Site do Campeonato da Igreja - Versão 2

Agora com:
- Layout mais bonito
- Armazenamento LocalStorage para registrar jogadores
- Escudos provisórios para 6 times

Pronto para subir no GitHub Pages.
